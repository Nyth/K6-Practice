import http from 'k6/http';
import { check,sleep } from 'k6';
import {Counter} from "k6/metrics";

//const baseUrl = 'http://jsonplaceholder.typicode.com';

export let ErrorCount=new Counter("errors");

export const option ={
vus :10,
duration :"20s",
thresholds:{
  errors :["counts<10"]
}
};

export default function(){
const path =Math.random<0.9 ? "200":"500";
let res =http.get('https://test.k6.io');
let success =check(res ,{
  "status is 200": r=>r.status==200
});
if(!success){
  ErrorCount.add(1);

}
sleep(2);

}

