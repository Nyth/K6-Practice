import http from 'k6/http';

export let options = {
  thresholds: {
    http_req_failed: ['rate<0.1'],   // http errors should be less than 10% 
    http_req_duration: ['p(90)<400'], // 90% of requests should be below 400ms
  },
};

export default function () {
  http.get('https://test-api.k6.io/public/crocodiles/1/');
}